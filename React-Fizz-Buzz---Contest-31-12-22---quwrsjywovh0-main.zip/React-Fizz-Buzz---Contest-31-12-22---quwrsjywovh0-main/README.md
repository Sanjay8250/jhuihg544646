# Fizz-Buzz-React

In this project lets, create a counter app with a fizz buzz twist to test out our conditional rendering skills.


First lets start by creating a counter, make a div with id="counter" inside which the counter starts with value 1.
Create two buttons with id="increment" and id="decrement" which as the name suggest increments and decrements the counter value.

In <code>src/styles/App.css</code>, we already have 4 classes defined.

<em>fizz</em>, <em>buzz</em>, <em>fizzbuzz</em>, <em>normal</em>

Now the #counter div will have a class which is one from the above accroding to below rules.

If number is divisible 3, it will have class of "fizz"
If number is divisible 5, it will have class of "buzz"
If number is divisible by 5 and 3, it will have class of "fizzbuzz"
If its neither of the above three cases, it will have a class of "normal"

<video src="" controls muted>





